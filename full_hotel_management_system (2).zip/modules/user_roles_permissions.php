
<?php
include_once("../fonksiyon/tema3fonk.php");
$tema3 = new vipTema;
$db = new mysqli("localhost", "root", "", "hotel_management") or die("Database connection failed");
$db->set_charset("utf8");

// Fetch roles
function fetchRoles() {
    global $tema3, $db;
    return $tema3->benimsorum2($db, "SELECT * FROM roles", 1);
}

// Add a new role
function addRole($role_name) {
    global $db;
    $stmt = $db->prepare("INSERT INTO roles (role_name) VALUES (?)");
    $stmt->bind_param("s", $role_name);
    $stmt->execute();
}

// Assign a permission to a role for a module
function assignPermission($role_id, $module, $can_access) {
    global $db;
    $stmt = $db->prepare("INSERT INTO permissions (role_id, module, can_access) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE can_access = VALUES(can_access)");
    $stmt->bind_param("isi", $role_id, $module, $can_access);
    $stmt->execute();
}

// Check if a user role has access to a specific module
function hasAccess($role_id, $module) {
    global $db;
    $stmt = $db->prepare("SELECT can_access FROM permissions WHERE role_id = ? AND module = ?");
    $stmt->bind_param("is", $role_id, $module);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    return !empty($result) && $result['can_access'] == 1;
}

// Display roles and their permissions
function displayRolesWithPermissions() {
    $roles = fetchRoles();
    while ($role = $roles->fetch_assoc()) {
        echo "<div>Role: {$role['role_name']}";
        // Fetch permissions for this role
        global $db;
        $role_id = $role['role_id'];
        $permissions = $db->query("SELECT * FROM permissions WHERE role_id = $role_id");
        while ($permission = $permissions->fetch_assoc()) {
            echo "<div>Module: {$permission['module']} - Access: " . ($permission['can_access'] ? 'Yes' : 'No') . "</div>";
        }
        echo "</div>";
    }
}
?>
