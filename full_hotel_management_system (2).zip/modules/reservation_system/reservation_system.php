
<?php
include_once("../fonksiyon/tema3fonk.php");
$tema3 = new vipTema;
$db = new mysqli("localhost", "root", "", "hotel_management") or die("Database connection failed");
$db->set_charset("utf8");

// Fetch reservations for a specific hotel
function fetchReservations($hotel_id) {
    global $tema3, $db;
    return $tema3->benimsorum2($db, "SELECT * FROM reservations WHERE hotel_id = ?", $hotel_id, 1);
}

// Check if a room is available for specified dates
function isRoomAvailable($room_id, $checkin, $checkout) {
    global $db;
    $stmt = $db->prepare("SELECT * FROM reservations WHERE room_id = ? AND (checkin < ? AND checkout > ?)");
    $stmt->bind_param("iss", $room_id, $checkout, $checkin);
    $stmt->execute();
    $result = $stmt->get_result();
    return ($result->num_rows === 0); // Room is available if no conflicting reservations
}

// Create a new reservation
function createReservation($hotel_id, $room_id, $guest_id, $checkin, $checkout) {
    global $db;
    if (isRoomAvailable($room_id, $checkin, $checkout)) {
        $stmt = $db->prepare("INSERT INTO reservations (hotel_id, room_id, guest_id, checkin, checkout, status) VALUES (?, ?, ?, ?, ?, 'Pending')");
        $stmt->bind_param("iiiss", $hotel_id, $room_id, $guest_id, $checkin, $checkout);
        $stmt->execute();
    } else {
        echo "Room is not available for the selected dates.";
    }
}

// Update an existing reservation
function updateReservation($reservation_id, $guest_id, $checkin, $checkout) {
    global $db;
    $stmt = $db->prepare("UPDATE reservations SET guest_id = ?, checkin = ?, checkout = ? WHERE reservation_id = ?");
    $stmt->bind_param("issi", $guest_id, $checkin, $checkout, $reservation_id);
    $stmt->execute();
}

// Cancel a reservation
function cancelReservation($reservation_id) {
    global $db;
    $stmt = $db->prepare("DELETE FROM reservations WHERE reservation_id = ?");
    $stmt->bind_param("i", $reservation_id);
    $stmt->execute();
}

// Display reservations for a specific hotel
function displayReservations($hotel_id) {
    $reservations = fetchReservations($hotel_id);
    while ($reservation = $reservations->fetch_assoc()) {
        echo "<div>Guest ID: {$reservation['guest_id']} - Room: {$reservation['room_id']} - Dates: {$reservation['checkin']} to {$reservation['checkout']} - Status: {$reservation['status']}</div>";
    }
}
?>
