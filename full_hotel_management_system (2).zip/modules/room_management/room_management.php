
<?php
include_once("../fonksiyon/tema3fonk.php");
$tema3 = new vipTema;
$db = new mysqli("localhost", "root", "", "hotel_management") or die("Database connection failed");
$db->set_charset("utf8");

// Fetch all rooms for a specific hotel
function fetchRooms($hotel_id) {
    global $tema3, $db;
    return $tema3->benimsorum2($db, "SELECT * FROM rooms WHERE hotel_id = ?", $hotel_id, 1);
}

// Add a new room to a hotel
function addRoom($hotel_id, $room_name, $room_type, $price) {
    global $db;
    $stmt = $db->prepare("INSERT INTO rooms (hotel_id, name, type, price, status) VALUES (?, ?, ?, ?, 'Available')");
    $stmt->bind_param("issd", $hotel_id, $room_name, $room_type, $price);
    $stmt->execute();
}

// Update existing room information
function updateRoom($room_id, $room_name, $room_type, $price, $status) {
    global $db;
    $stmt = $db->prepare("UPDATE rooms SET name = ?, type = ?, price = ?, status = ? WHERE room_id = ?");
    $stmt->bind_param("ssdsi", $room_name, $room_type, $price, $status, $room_id);
    $stmt->execute();
}

// Delete a room
function deleteRoom($room_id) {
    global $db;
    $stmt = $db->prepare("DELETE FROM rooms WHERE room_id = ?");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
}

// Display rooms with status and type
function displayRooms($hotel_id) {
    $rooms = fetchRooms($hotel_id);
    while ($room = $rooms->fetch_assoc()) {
        echo "<div>Room: {$room['name']} - Type: {$room['type']} - Price: {$room['price']} - Status: {$room['status']}</div>";
    }
}
?>
