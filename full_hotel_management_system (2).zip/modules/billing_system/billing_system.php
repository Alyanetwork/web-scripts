
<?php
include_once("../fonksiyon/tema3fonk.php");
$tema3 = new vipTema;
$db = new mysqli("localhost", "root", "", "hotel_management") or die("Database connection failed");
$db->set_charset("utf8");

// Fetch invoices for a specific hotel
function fetchInvoices($hotel_id) {
    global $tema3, $db;
    return $tema3->benimsorum2($db, "SELECT * FROM invoices WHERE hotel_id = ?", 1);
}

// Create a new invoice for a reservation
function createInvoice($hotel_id, $reservation_id, $amount, $description) {
    global $db;
    $stmt = $db->prepare("INSERT INTO invoices (hotel_id, reservation_id, amount, description, status) VALUES (?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("iids", $hotel_id, $reservation_id, $amount, $description);
    $stmt->execute();
}

// Update the status of an invoice (e.g., marking it as paid)
function updateInvoiceStatus($invoice_id, $status) {
    global $db;
    $stmt = $db->prepare("UPDATE invoices SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $invoice_id);
    $stmt->execute();
}

// Record a payment for an invoice
function recordPayment($invoice_id, $payment_amount) {
    global $db;
    $stmt = $db->prepare("UPDATE invoices SET status = 'Paid' WHERE id = ?");
    $stmt->bind_param("i", $invoice_id);
    $stmt->execute();
    // Additional payment tracking functionality could be implemented here.
}

// Display invoices for a specific hotel
function displayInvoices($hotel_id) {
    $invoices = fetchInvoices($hotel_id);
    while ($invoice = $invoices->fetch_assoc()) {
        echo "<div>Invoice: {$invoice['description']} - Amount: {$invoice['amount']} - Status: {$invoice['status']}</div>";
    }
}
?>
