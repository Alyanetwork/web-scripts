
<?php
include_once("../fonksiyon/tema3fonk.php");
$tema3 = new vipTema;
$db = new mysqli("localhost", "root", "", "hotel_management") or die("Database connection failed");
$db->set_charset("utf8");

session_start();
$user_role_id = $_SESSION['role_id']; // Assume role_id is stored in session upon login

// Function to check if the logged-in user has access to a module
function canAccess($module) {
    global $user_role_id, $db;
    $stmt = $db->prepare("SELECT can_access FROM permissions WHERE role_id = ? AND module = ?");
    $stmt->bind_param("is", $user_role_id, $module);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    return $result && $result['can_access'] == 1;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Admin Dashboard - Hotel Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1>Admin Dashboard</h1>

    <div class="row">
        <!-- Room Management -->
        <?php if (canAccess('Room Management')): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Room Management</h5>
                        <a href="../modules/room_management/room_management.php" class="btn btn-primary">Manage Rooms</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Reservation System -->
        <?php if (canAccess('Reservation System')): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Reservation System</h5>
                        <a href="../modules/reservation_system/reservation_system.php" class="btn btn-primary">Manage Reservations</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Billing System -->
        <?php if (canAccess('Billing System')): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Billing System</h5>
                        <a href="../modules/billing_system/billing_system.php" class="btn btn-primary">Manage Billing</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- User Roles and Permissions -->
        <?php if (canAccess('User Management')): ?>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">User Management</h5>
                        <a href="../modules/user_roles_permissions.php" class="btn btn-primary">Manage Roles</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
